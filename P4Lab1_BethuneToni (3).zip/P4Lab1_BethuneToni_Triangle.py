# Toni Bethune
# 04042925
# P4LAB
# Import Turtle with Square and Triangle

import turtle

# Create a turtle object
pen = turtle.Turtle()

# Set the turtle shape
pen.shape("turtle")


# Draw triangle using a while loop
count = 0
while count < 3:
    pen.forward(100)
    pen.left(120)
    count += 1

turtle.done()
