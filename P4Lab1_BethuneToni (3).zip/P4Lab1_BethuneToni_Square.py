# Toni Bethune
# 04042925
# P4LAB
# Import Turtle with Square and Triangle

import turtle

# Create a turtle object
pen = turtle.Turtle()

# Set the turtle shape
pen.shape("turtle")

# Draw square using a for loop
for i in range(4):
    pen.forward(100)
    pen.left(90)



turtle.done()
