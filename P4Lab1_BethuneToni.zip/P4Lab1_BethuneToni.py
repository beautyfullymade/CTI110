# Toni Bethune
# 04042925
# P4LAB
# Import Turtle with Square and Triangle

import turtle

# Draw a square using a for loop
for _ in range(4):
    turtle.forward(100)  # move forward by 100 units
    turtle.left(90)      # turn left 90 degrees     


# Draw a triangle using a for loop
for _ in range(3):
    turtle.forward(100)
    turtle.left(120)
